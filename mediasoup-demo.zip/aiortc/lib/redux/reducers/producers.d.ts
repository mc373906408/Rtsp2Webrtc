declare const producers: (state: {}, action: any) => any;
export default producers;
//# sourceMappingURL=producers.d.ts.map