export declare function getProtooUrl({ roomId, peerId, forceH264, forceVP8 }: {
    roomId: string;
    peerId: string;
    forceH264: boolean;
    forceVP8: boolean;
}): string;
//# sourceMappingURL=urlFactory.d.ts.map