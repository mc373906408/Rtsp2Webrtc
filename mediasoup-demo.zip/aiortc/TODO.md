
* aiortc RTCPeerConnection does not seem to return from `close()`.
