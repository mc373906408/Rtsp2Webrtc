#!/usr/bin/env node

const interactiveClient = require('./lib/interactiveClient');

interactiveClient();
