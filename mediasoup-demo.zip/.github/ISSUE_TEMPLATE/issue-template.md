---
name: Issue template
about: Use this option to report an issue in mediasoup-demo
title: ''
labels: ''
assignees: ''

---

**IMPORTANT:** We primarily use GitHub as an issue tracker. Just open an issue here if you have encountered a real bug in the mediasoup-demo project.

If you have questions or doubts about mediasoup or about the mediasoup-demo project, or need support, please use the mediasoup Discourse Group instead:

https://mediasoup.discourse.group

**TO BE CLEAR:** Don't open an issue here to ask questions about mediasoup or mediasoup-demo.
